Name : SRIHARI CHANDRAMOULI
UTA ID: 1001529776
Programming Language: PYTHON

CODE STRUCTURE
*************
1. The hypothesis that has been given in the question has been firstly defined as Hypo in the program.
2. Then the prior probabilities have been stored in the prevProb.
3. Then as per the question, the observations have been stored in the 1st command line argument.
4. The output is stored in a text file known as "result.txt".

COMPILATION AND EXECUTION
*************************
python compute_a_posteriori.py [observations]
for example
python compute_a_posteriori.py CCLLCLL

CITATIONS
*********
1. https://github.com/siddhantgawsane/ArtificialIntelligence1/blob/master/assignment5/compute_a_posteriori.py
2. http://dataconomy.com/2015/02/introduction-to-bayes-theorem-with-python/