from sys import argv

if len(argv) > 1:
	obs = argv[1]                                             #Command Line Arguments
else:
	obs = ""

createFile = open("result.txt", 'w+')							#Creation of the file

createFile.write("Observation Sequence Q: %s\n" % obs)			#The necessary statements
createFile.write("Length of Q: %i\n" % len(obs))

obs = obs.upper()
obs = " "+obs +"C"

Hypo = [{ 'h1':0.1, 'h2':0.2, 'h3':0.4, 'h4':0.2, 'h5':0.1 }]		#The hypothesis given
#The below is the prior probabilities that are given
prevProb = {

				'C|h1': 1, 'L|h1': 0,
				'C|h2': 0.75, 'L|h2': 0.25,
				'C|h3': 0.5, 'L|h3': 0.5,
				'C|h4': 0.25, 'L|h4': 0.75,
				'C|h5': 0, 'L|h5': 1
 }

Queries = []
p=0
for i in range(1,6):
	temp = (prevProb[obs[1]+'|h'+str(i)] * Hypo[0]['h'+str(i)])

	p = p + temp

Queries.append({obs[1]:p})
length = len(obs)

for j in range(1,length-1):
	if len(Hypo)-1 < j:
		Hypo.append({})
	if len(Queries)-1 < j:
		Queries.append({})

	temp = 0
	for i in range(1,6):
		Hypo[j]['h'+str(i)] = prevProb[obs[j]+'|h'+str(i)] * Hypo[j-1]['h'+str(i)] / Queries[j-1][obs[j]]
		temp = temp + prevProb[obs[j+1]+'|h'+str(i)] * Hypo[j]['h'+str(i)]
	Queries[j][obs[j+1]] = temp

for i in range(1,6):
	createFile.write("P(h%d|Q) = %.5f\n" % (i, Hypo[-1]["h"+str(i)]))

NextIsC = Queries[-1]["C"]
createFile.write("Probability that the next candy we pick will be C, given Q: %.5f\n" % NextIsC)
createFile.write("Probability that the next candy we pick will be L, given Q: %.5f\n" % (1.000-NextIsC))
createFile.close()