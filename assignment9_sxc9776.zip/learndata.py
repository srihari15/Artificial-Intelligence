from sys import argv

script, dataFile = argv

txt = open(dataFile)
g = 0
w = 0
o = 0
f = 0
total = 365
pWgivenG = 0
pFandWandO = 0
pFandWandNotO = 0
pFandOandNotW = 0
pWandO = 0
pWandNotO = 0
pNotWandO = 0
pNotWandNotO = 0

for line in txt:
    temp = line.split()

    baseball_game_on_TV = int(temp[0])
    George_watches_TV = int(temp[1])
    out_of_cat_food = int(temp[2])
    George_feeds_cat = int(temp[3])

    if baseball_game_on_TV:
        g = g + 1
    if George_watches_TV:
        w = w + 1
    if out_of_cat_food:
        o = o + 1
    if George_feeds_cat:
        f = f + 1

    if baseball_game_on_TV and George_watches_TV:
        pWgivenG = pWgivenG + 1
    if George_feeds_cat:
        if George_watches_TV and out_of_cat_food:
            pFandWandO = pFandWandO + 1
        else:
            if George_watches_TV:
                pFandWandNotO = pFandWandNotO + 1
            if out_of_cat_food:
                pFandOandNotW = pFandOandNotW + 1
    if George_watches_TV and out_of_cat_food:
        pWandO = pWandO + 1
    if George_watches_TV and not out_of_cat_food:
        pWandNotO = pWandNotO + 1
    if not George_watches_TV and out_of_cat_food:
        pNotWandO = pNotWandO + 1
    if not George_watches_TV and not out_of_cat_food:
        pNotWandNotO = pNotWandNotO + 1
txt.close()

print "\nP(baseball_game_on_TV)\n%.5f\n" % (float(g) / total)
print "\nP(out_of_cat_food)\n%.5f\n" % (float(o) / total)
print "\nP(George_watches_TV|baseball_game_on_TV)"
print "baseball_game_on_TV=True	%.5f" % (float(pWgivenG) / g)
print "baseball_game_on_TV=False	%.5f\n" % (float(w - pWgivenG) / (total - g))
print "\nP(George_feeds_cat|George_watches_TV,out_of_cat_food)"
print "George_watches_TV=True,out_of_cat_food=True	%.5f" % (float(pFandWandO) / pWandO)
print "George_watches_TV=True,out_of_cat_food=False	%.5f" % (float(pFandWandNotO) / pWandNotO)
print "George_watches_TV=False,out_of_cat_food=True	%.5f" % (float(pFandOandNotW) / pNotWandO)
print "George_watches_TV=False,out_of_cat_food=False	%.5f\n" % (
float(f - pFandWandO - pFandWandNotO - pFandOandNotW) / pNotWandNotO)