NAME : SRIHARI CHANDRAMOULI
UTA ID : 1001529776
PROGRAMMING LANGUAGE : PYTHON

CODE STRUCTURE
*************
1. For task 2, we have computed the probabilities based on the training datas which I have stored it in a file called
training_data.txt. All the probabilities have been computed upto 5 decimal places.
Based on the results of task 2, I have created a table and incorporated it in the task 1 along with the diagram.
2. For task 3, according to the table given in the question, I have constructed a Bayesian Network for each and every
values given in the table. After that, I have computed and then generated the values according to the question.

COMPILATION AND EXECUTION
************************
1. For task 2,
python learndata.py training_data.txt
Here training_data.txt is the command line argument. We can give any file with the suitable datas.
2. For task 3, as given in the question
python bnet.py [query1] [query2] [query3] ... given [observation1] [observation2] [observation3]
for example python bnet.py Bt Af given Mf
the 'given' argument is optional, its absence will mark all inputs as queries
for example python bnet.py Bt Af Mf Jt Et
3. For task1 and task4, I have included two separate pdf files one for each task.

CREDITS
*******
https://github.com/siddhantgawsane/ArtificialIntelligence1/blob/master/assignment5/bnet.py
https://github.com/siddhantgawsane/ArtificialIntelligence1/blob/master/assignment5/learn_test_data.py