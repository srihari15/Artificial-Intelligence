                                    ASSIGNMENT 5
                                    ************

****************************
NAME: SRIHARI CHANDRAMOULI
UTA ID: 1001529776
PROGRAMMING LANGUAGE: JAVA
****************************

CODE STRUCTURE
**************
            ttCheckall() -> This method is used to check the equivalence between the knowledge base and the propositional logic statement
                            that is given as the input.

            Pltrue() -> This method checks whether the statements in the knowledge base is correct or not.

            Get_symbol() -> This method basically checks the symbols that are inputted and it finds out if or not that exists
                            in the knowledge base.

            The output is printed both in the console and in a text file known as result.txt

COMPILATION AND EXECUTION
**************************
1. All files should be in the same directory
2. Firstly compile the java file using the command:
			javac *.java   (in omega)
3. Command for execution - java CheckTrueFalse wumpus_rules.txt kb.txt statement.txt
4. kb.txt is the additional knowledge file.

CITATION
********
Link: https://github.com/HarshaMysur/WumpusWorld---Building-an-intelligent-agent-to-Predict-whats-in-the-next-block
Author: Harsh
Available in Github