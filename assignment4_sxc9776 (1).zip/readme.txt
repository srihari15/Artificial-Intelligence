Name : Srihari Chandramouli

UTA ID: 1001529776

Programming Language: Python


CODE STRUCTURE

**************
	
A class called Minimax is written in MaxConnect4Game.py where there 
are many functions like:
	
makeDecision()- This returns minimax's decision

maxval()- This function is used to perform the maximizing operations.  
	
minval()- This function is used to perform the minimizing operations.
	
utility()- Returns the utility required for the maximizing and
 minimization opperations.
	
result()- This definition is used to return a new state after one
 particular move.

possibleMoves()- This function returns the possible variabilities
 possible in that particular state.


COMPILATION

***********
	
To run the program, execute the maxconnect4.py. There are two modes in
the program:

	a) One-move mode
	
	b) Interactive mode

For the one-move mode:

python maxconnect4.py one-move input-file.txt output-file.txt depth

For the interactive mode:

python maxconnect4.py interactive input-file.txt human-next/computer-next depth


CITATIONS

*********

Author name: Siddhant Gawsane

Title: ArtificialIntelligence1

Link: www.github.com/siddhantgawsane/Artificialintelligence1/tree/master/Assignment2


TOURNAMENT

**********

I am not enrolling in the tournament.


