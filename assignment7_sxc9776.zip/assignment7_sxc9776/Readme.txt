NAME : SRIHARI CHANDRAMOULI
UTA ID: 1001529776

Compiling And Running
*********************
Make sure that all the text files are in the same directory of that of the graphplan.
To compile the software, use the command:
	make graphplan
Once it compiles, use the following command:
	graphplan -o [operators_file] -f [facts_file]

The zipped file contains the written part of the assignment named assignment7_sxc9776.pdf and the 6 text files
(Both for tower of hanoi and 7 puzzle).


Credits
*******
https://github.com/siddhantgawsane/ArtificialIntelligence1/tree/master/assignment4/graphplan 